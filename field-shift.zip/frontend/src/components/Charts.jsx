import React, { useState } from "react";

/**
 * Charts Component (Spec Section 46, 52, 54)
 * Visualizes 61-day NASA observation anomalies and stress metrics with prominent Spec Section 52 Source Attributions.
 */
export default function Charts({ fieldId, nasaMetadata, language = "en" }) {
  const isBn = language === "bn";
  const [activeTab, setActiveTab] = useState("water"); // 'water' | 'heat' | 'vegetation'

  return (
    <div className="bg-[#092619]/90 border border-emerald-500/20 rounded-2xl p-4 sm:p-5 md:p-6 shadow-xl shadow-black/25 backdrop-blur-md">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3.5 pb-3 border-b border-emerald-800/40">
        <div>
          <span className="text-xs sm:text-sm font-bold uppercase tracking-wider text-emerald-400 block mb-1">
            {isBn
              ? "সময়কাল গতিপ্রকৃতি (৩০ ডিসেম্বর ২০২৩ - ২৮ ফেব্রুয়ারি ২০২৪)"
              : "Time-Series Dynamics (Dec 30, 2023 – Feb 28, 2024)"}
          </span>
          <h3 className="text-xl sm:text-2xl md:text-2xl font-black text-white tracking-tight font-heading">
            {isBn
              ? "৬১-দিনের পরিবেশগত চাপের ধারাবাহিক চিত্র"
              : "61-Day Environmental Stress Trends"}
          </h3>
        </div>

        {/* Tab Controls */}
        <div className="grid grid-cols-3 sm:inline-flex rounded-xl bg-[#04140d] p-1 border border-emerald-800/60 text-xs sm:text-sm w-full sm:w-auto gap-1">
          <button
            onClick={() => setActiveTab("water")}
            className={`px-2.5 sm:px-3.5 py-1.5 rounded-lg font-bold transition-all text-center truncate cursor-pointer ${
              activeTab === "water"
                ? "bg-cyan-500 text-white shadow-sm"
                : "text-emerald-300/70 hover:text-white"
            }`}
          >
            💧 {isBn ? "পানির চাপ" : "Water Stress"}
          </button>
          <button
            onClick={() => setActiveTab("heat")}
            className={`px-2.5 sm:px-3.5 py-1.5 rounded-lg font-bold transition-all text-center truncate cursor-pointer ${
              activeTab === "heat"
                ? "bg-amber-500 text-white shadow-sm"
                : "text-emerald-300/70 hover:text-white"
            }`}
          >
            🔥 {isBn ? "তাপীয় চাপ" : "Heat & LST"}
          </button>
          <button
            onClick={() => setActiveTab("vegetation")}
            className={`px-2.5 sm:px-3.5 py-1.5 rounded-lg font-bold transition-all text-center truncate cursor-pointer ${
              activeTab === "vegetation"
                ? "bg-emerald-500 text-white shadow-sm"
                : "text-emerald-300/70 hover:text-white"
            }`}
          >
            🌱 {isBn ? "উদ্ভিজ্জ EVI" : "Vegetation EVI"}
          </button>
        </div>
      </div>

      {/* SVG Chart Display */}
      <div className="w-full aspect-[16/7] min-h-[200px] bg-[#04140d] rounded-2xl border border-emerald-800/60 p-3 sm:p-4 relative overflow-hidden flex flex-col justify-between shadow-inner">
        {/* WATER STRESS TAB */}
        {activeTab === "water" && (
          <>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5 sm:gap-2 text-xs mb-3">
              <span className="font-bold text-cyan-300">
                {isBn
                  ? "SMAP মাটির আর্দ্রতা এবং IMERG ৩০-দিনের ক্রমপুঞ্জিত বৃষ্টিপাত"
                  : "SMAP Volumetric Soil Moisture & IMERG 30d Rolling Rainfall"}
              </span>
              {/* Mandatory Spec Section 52 NASA Source Attribution */}
              <span className="text-[10px] sm:text-[11px] font-mono px-2 sm:px-2.5 py-0.5 rounded-md sm:rounded-full bg-cyan-950/80 border border-cyan-800 text-cyan-200 break-words self-start sm:self-auto leading-tight">
                {isBn ? "উৎস: " : "Source: "}
                {nasaMetadata?.smap_product || "SPL3SMP_E"}.
                {nasaMetadata?.smap_version || "006"} (9km) &{" "}
                {nasaMetadata?.gpm_product || "GPM_3IMERGDF"}.
                {nasaMetadata?.gpm_version || "07"}{" "}
                {nasaMetadata?.gpm_latency_class || "Final"} (~10km)
              </span>
            </div>

            <svg viewBox="0 0 600 160" className="w-full h-full">
              {/* Baseline Reference Line */}
              <line
                x1="40"
                y1="80"
                x2="580"
                y2="80"
                stroke="#0f3d27"
                strokeDasharray="4 4"
                strokeWidth="1.5"
              />
              <text x="45" y="74" fill="#6ee7b7" fontSize="10" opacity="0.8">
                {isBn
                  ? "ঐতিহাসিক বেসলাইন গড় (z = ০)"
                  : "Historical Baseline Mean (z = 0)"}
              </text>

              {/* Stress Fill Area */}
              <path
                d="M 50 110 Q 150 120 250 125 T 450 135 T 570 140 L 570 80 L 50 80 Z"
                fill="rgba(34, 211, 238, 0.12)"
              />

              {/* Rolling 30d Rainfall Trendline */}
              <path
                d="M 50 110 Q 150 120 250 125 T 450 135 T 570 140"
                fill="none"
                stroke="#22d3ee"
                strokeWidth="2.5"
                strokeLinecap="round"
              />

              {/* SMAP Soil Moisture Anomaly */}
              <path
                d="M 50 95 Q 120 105 200 108 T 380 120 T 570 130"
                fill="none"
                stroke="#06b6d4"
                strokeWidth="2"
                strokeDasharray="6 3"
              />
            </svg>

            <div className="flex flex-col sm:flex-row sm:items-center justify-between text-[10px] sm:text-[11px] text-emerald-200/70 pt-2 border-t border-emerald-900/60 gap-1.5 sm:gap-2">
              <div className="flex flex-wrap items-center gap-2.5 sm:gap-4">
                <span className="flex items-center gap-1.5">
                  <span className="w-3 h-0.5 bg-cyan-400"></span>{" "}
                  {isBn
                    ? "GPM ৩০ দিনের বৃষ্টিপাত যোগফল"
                    : "GPM 30d Rainfall Sum"}
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-3 h-0.5 bg-cyan-600 border-b border-dashed"></span>{" "}
                  {isBn
                    ? "SMAP ০-৫ সেমি মাটির আর্দ্রতা"
                    : "SMAP 0-5cm Moisture"}
                </span>
              </div>
              <span className="text-emerald-100 font-medium italic">
                {isBn
                  ? "৬১টি দৈনিক পর্যবেক্ষণ (৩০ ডিসে ২০২৩ – ২৮ ফেব্রু ২০২৪)"
                  : "61 Daily Observations (Dec 30, 2023 – Feb 28, 2024)"}
              </span>
            </div>
          </>
        )}

        {/* HEAT STRESS TAB */}
        {activeTab === "heat" && (
          <>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5 sm:gap-2 text-xs mb-3">
              <span className="font-bold text-amber-300">
                {isBn
                  ? "MODIS দিন ও রাতের ভূপৃষ্ঠ তাপমাত্রা (°C) + উষ্ণ দিনের পুনরাবৃত্তি"
                  : "MODIS Daytime & Nighttime LST (°C) + Hot-Day Frequency"}
              </span>
              {/* Mandatory Spec Section 52 NASA Source Attribution */}
              <span className="text-[10px] sm:text-[11px] font-mono px-2 sm:px-2.5 py-0.5 rounded-md sm:rounded-full bg-amber-950/80 border border-amber-800 text-amber-200 break-words self-start sm:self-auto leading-tight">
                {isBn ? "উৎস: " : "Source: "}MODIS Terra MOD11A1 & Aqua MYD11A1
                v{nasaMetadata?.modis_version || "061"} (1km Thermal)
              </span>
            </div>

            <svg viewBox="0 0 600 160" className="w-full h-full">
              {/* Hot-day threshold line at z >= 1.0 */}
              <line
                x1="40"
                y1="45"
                x2="580"
                y2="45"
                stroke="#f43f5e"
                strokeDasharray="3 3"
                strokeWidth="1.5"
              />
              <text
                x="45"
                y="40"
                fill="#f43f5e"
                fontSize="10"
                fontWeight="bold"
              >
                {isBn
                  ? "উষ্ণ দিনের ঝুঁকি সীমা (z ≥ ১.০ σ)"
                  : "Hot Day Threshold (z ≥ 1.0 σ)"}
              </text>

              {/* Baseline Reference Line */}
              <line
                x1="40"
                y1="95"
                x2="580"
                y2="95"
                stroke="#0f3d27"
                strokeDasharray="4 4"
                strokeWidth="1.5"
              />
              <text x="45" y="90" fill="#6ee7b7" fontSize="10" opacity="0.8">
                {isBn ? "বেসলাইন গড়" : "Baseline Mean"}
              </text>

              {/* Daytime LST Temperature curve */}
              <path
                d="M 50 110 Q 120 70 200 85 T 320 40 T 420 50 T 520 38 T 570 42"
                fill="none"
                stroke="#f59e0b"
                strokeWidth="2.5"
                strokeLinecap="round"
              />

              {/* Nighttime LST Temperature curve */}
              <path
                d="M 50 130 Q 140 120 220 125 T 380 110 T 570 105"
                fill="none"
                stroke="#fbbf24"
                strokeWidth="1.5"
                strokeDasharray="4 2"
              />
            </svg>

            <div className="flex flex-col sm:flex-row sm:items-center justify-between text-[10px] sm:text-[11px] text-emerald-200/70 pt-2 border-t border-emerald-900/60 gap-1.5 sm:gap-2">
              <div className="flex flex-wrap items-center gap-2.5 sm:gap-4">
                <span className="flex items-center gap-1.5">
                  <span className="w-3 h-0.5 bg-amber-400"></span>{" "}
                  {isBn ? "দিনের LST তাপমাত্রা (Terra)" : "Daytime LST (Terra)"}
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-3 h-0.5 bg-amber-300 border-b border-dashed"></span>{" "}
                  {isBn ? "রাতের LST তাপমাত্রা (Aqua)" : "Nighttime LST (Aqua)"}
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-3 h-0.5 bg-rose-500"></span>{" "}
                  {isBn ? "সীমা z ≥ ১.০" : "Threshold z ≥ 1.0"}
                </span>
              </div>
              <span className="text-emerald-100 font-medium italic">
                {isBn
                  ? "উষ্ণ দিনের সংখ্যা তাপ গুণকে প্রভাব ফেলে"
                  : "Hot-day counts feed heat multiplier"}
              </span>
            </div>
          </>
        )}

        {/* VEGETATION TAB */}
        {activeTab === "vegetation" && (
          <>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5 sm:gap-2 text-xs mb-3">
              <span className="font-bold text-emerald-300">
                {isBn
                  ? "হারমোনাইজড ল্যান্ডস্যাট-সেন্টিনেল (HLS) ৩০ মি. EVI ক্যানোপি বিচ্যুতি"
                  : "Harmonized Landsat-Sentinel (HLS) 30m EVI Canopy Anomaly"}
              </span>
              {/* Mandatory Spec Section 52 NASA Source Attribution */}
              <span className="text-[10px] sm:text-[11px] font-mono px-2 sm:px-2.5 py-0.5 rounded-md sm:rounded-full bg-emerald-950/80 border border-emerald-800 text-emerald-200 break-words self-start sm:self-auto leading-tight">
                {isBn ? "উৎস: " : "Source: "}HLS HLSL30_VI & HLSS30_VI v
                {nasaMetadata?.hls_version || "2.0"} (30m Optical/NIR/SWIR)
              </span>
            </div>

            <svg viewBox="0 0 600 160" className="w-full h-full">
              {/* Baseline Reference Line */}
              <line
                x1="40"
                y1="75"
                x2="580"
                y2="75"
                stroke="#0f3d27"
                strokeDasharray="4 4"
                strokeWidth="1.5"
              />
              <text x="45" y="70" fill="#6ee7b7" fontSize="10" opacity="0.8">
                {isBn
                  ? "ফসল-সামঞ্জস্যপূর্ণ ঐতিহাসিক গড় (EVI বেসলাইন)"
                  : "Historical Crop-Matched Mean (EVI Baseline)"}
              </text>

              {/* EVI Observation Points & Line */}
              <path
                d="M 60 70 L 110 72 L 170 80 L 230 85 L 300 90 L 370 98 L 440 102 L 510 105 L 560 110"
                fill="none"
                stroke="#10b981"
                strokeWidth="2.5"
                strokeLinecap="round"
              />

              {/* Data points */}
              {[
                { x: 60, y: 70 },
                { x: 110, y: 72 },
                { x: 170, y: 80 },
                { x: 230, y: 85 },
                { x: 300, y: 90 },
                { x: 370, y: 98 },
                { x: 440, y: 102 },
                { x: 510, y: 105 },
                { x: 560, y: 110 },
              ].map((pt, i) => (
                <circle
                  key={i}
                  cx={pt.x}
                  cy={pt.y}
                  r="4"
                  fill="#34d399"
                  stroke="#04140d"
                  strokeWidth="1.5"
                />
              ))}
            </svg>

            <div className="flex flex-col sm:flex-row sm:items-center justify-between text-[10px] sm:text-[11px] text-emerald-200/70 pt-2 border-t border-emerald-900/60 gap-1.5 sm:gap-2">
              <div className="flex flex-wrap items-center gap-2.5 sm:gap-4">
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400"></span>{" "}
                  {isBn
                    ? "কার্যকর HLS অপটিক্যাল উপগ্রহ পর্যবেক্ষণ"
                    : "Valid HLS Optical Observations"}
                </span>
              </div>
              <span className="text-emerald-100 font-medium italic">
                {isBn
                  ? "৩০ দিনের জানালায় ১০-১২টি মেঘমুক্ত দৃশ্য"
                  : "10–12 Cloud-free scenes across 30d window"}
              </span>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
